// Declaração de variáveis
let clientes = [];

// Função para listar todos os clientes
const listarClientes = () => {
    const tabela = document.querySelector('table tbody');

    // Limpar conteúdo da tabela
    tabela.innerHTML = '';

    // Adicionar cada cliente na tabela
    clientes.forEach((cliente, indice) => {
        const novaLinha = tabela.insertRow();

        // Preencher células da linha com os dados do cliente
        const celulaNome = novaLinha.insertCell(0);
        celulaNome.textContent = cliente.nome + ' ' + cliente.sobrenome;

        const celulaDataNascimento = novaLinha.insertCell(1);
        celulaDataNascimento.textContent = cliente.dataNascimento;

        const celulaTipoCliente = novaLinha.insertCell(2);
        celulaTipoCliente.textContent = cliente.tipoCliente;

        const celulaEndereco = novaLinha.insertCell(3);
        celulaEndereco.textContent = cliente.endereco + ', ' + cliente.numero + ' - ' + cliente.cidade;

        const celulaAcao = novaLinha.insertCell(4);

        // Adicionar botões de ação (excluir e alterar) na célula
        const btnExcluir = document.createElement('button');
        btnExcluir.textContent = 'Excluir';
        btnExcluir.addEventListener('click', () => excluirCliente(indice));
        celulaAcao.appendChild(btnExcluir);

        const btnAlterar = document.createElement('button');
        btnAlterar.textContent = 'Alterar';
        btnAlterar.addEventListener('click', () => alterarCliente(indice));
        celulaAcao.appendChild(btnAlterar);
    });
};

// Função para incluir um cliente
const incluirCliente = () => {
    // Obter valores do formulário
    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const tipoCliente = document.getElementById('cliente').value;
    const dataNascimento = document.getElementById('dtnasc').value;
    const cep = document.getElementById('CEP').value;
    const cidade = document.getElementById('cidade').value;
    const endereco = document.getElementById('endereco').value;
    const numero = document.getElementById('num').value;

    // Criar objeto cliente
    const novoCliente = {
        nome,
        sobrenome,
        tipoCliente,
        dataNascimento,
        cep,
        cidade,
        endereco,
        numero
    };

    // Adicionar cliente ao array
    clientes.push(novoCliente);

    // Limpar campos do formulário
    limparTela();

    // Atualizar a tabela
    listarClientes();
};

// Função para limpar a tela
const limparTela = () => {
    // Limpar valores dos campos do formulário
    document.getElementById('nome').value = '';
    document.getElementById('sobrenome').value = '';
    document.getElementById('cliente').value = '';
    document.getElementById('dtnasc').value = '';
    document.getElementById('CEP').value = '';
    document.getElementById('cidade').value = '';
    document.getElementById('endereco').value = '';
    document.getElementById('num').value = '';
};

// Função para excluir um cliente
const excluirCliente = (indice) => {
    // Remover cliente do array
    clientes.splice(indice, 1);

    // Atualizar a tabela
    listarClientes();
};

// Função para alterar um cliente
const alterarCliente = (indice) => {
    // Obter o cliente pelo índice
    const clienteSelecionado = clientes[indice];

    // Preencher campos do formulário com os dados do cliente
    document.getElementById('nome').value = clienteSelecionado.nome;
    document.getElementById('sobrenome').value = clienteSelecionado.sobrenome;
    document.getElementById('cliente').value = clienteSelecionado.tipoCliente;
    document.getElementById('dtnasc').value = clienteSelecionado.dataNascimento;
    document.getElementById('CEP').value = clienteSelecionado.cep;
    document.getElementById('cidade').value = clienteSelecionado.cidade;
    document.getElementById('endereco').value = clienteSelecionado.endereco;
    document.getElementById('num').value = clienteSelecionado.numero;
    
    // Remover cliente do array
    clientes.splice(indice, 1);

    // Atualizar a tabela
    listarClientes();
};
