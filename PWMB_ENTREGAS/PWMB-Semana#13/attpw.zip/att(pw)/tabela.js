const preencherTabela = () => {
    const tabela = document.querySelector('table');
    const dadosLocalStorage = localStorage.getItem('clientes');
    const clientes = JSON.parse(dadosLocalStorage);

    // Limpar conteúdo da tabela
    tabela.innerHTML = '';

    if (clientes && clientes.length > 0) {
        clientes.forEach(cliente => {
            const novaLinha = tabela.insertRow(-1);
            novaLinha.insertCell(0).textContent = cliente.nome + " " + cliente.sobrenome;
            novaLinha.insertCell(1).textContent = cliente.dataNascimento;
            novaLinha.insertCell(2).textContent = cliente.CEP;

            // Verificar se o campo 'endereco' está definido antes de acessá-lo
            const endereco = cliente.endereco ? cliente.endereco + " " + cliente.numero : "N/A";
            novaLinha.insertCell(3).textContent = endereco;

            // Adiciona a classe para tornar a linha selecionável
            novaLinha.classList.add('cliente', cliente.length);

            // Adiciona evento de clique para selecionar a linha
            novaLinha.addEventListener('click', () => {
                selecionarLinha(novaLinha);
            });

            // Adiciona o botão de excluir com o evento de clique
            novaLinha.insertCell(4).innerHTML = `<div class="btnexcluir"><button onclick="excluirLinha(${cliente.length})"><img src="lixeira.png" alt="some text" width=20 height=10></button></div>`;
        });
    }
};

// Função para excluir uma linha da tabela e do localStorage
const excluirLinha = (clienteLength) => {
    const linhaParaExcluir = document.querySelector(`.${clienteLength}`);

    if (linhaParaExcluir) {
        // Buscar dados do localStorage
        const dadosLocalStorage = localStorage.getItem('clientes');
        const clientes = JSON.parse(dadosLocalStorage);

        // Encontrar e remover o cliente correspondente
        const clienteIndex = clientes.findIndex(cliente => cliente.length === clienteLength);

        if (clienteIndex !== -1) {
            clientes.splice(clienteIndex, 1);

            // Atualizar o Local Storage
            localStorage.setItem('clientes', JSON.stringify(clientes));
        } else {
            console.error('Cliente não encontrado para exclusão.');
        }

        // Remove a linha
        linhaParaExcluir.remove();
    } else {
        console.error('Linha não encontrada para exclusão.');
    }
};

// Função para selecionar uma linha
const selecionarLinha = (linha) => {
    // Remove a classe 'selecionada' de todas as linhas
    const linhas = document.querySelectorAll('table tr');
    linhas.forEach(l => l.classList.remove('selecionada'));

    // Adiciona a classe 'selecionada' à linha clicada
    linha.classList.add('selecionada');
};

// Função para excluir linhas selecionadas
const excluirSelecionados = () => {
    // Encontrar a linha selecionada
    const linhaSelecionada = document.querySelector('.selecionada');

    if (linhaSelecionada) {
        // Obter o clienteLength da linha selecionada
        const clienteLength = linhaSelecionada.classList[1];

        // Chamar a função para excluir a linha
        excluirLinha(clienteLength);
    } else {
        console.error('Nenhuma linha selecionada.');
    }
};

// Função para limpar os campos do formulário
const limparCampos = () => {
    document.getElementById('nome').value = '';
    document.getElementById('sobrenome').value = '';
    document.getElementById('UF').value = '';
    document.getElementById('dtnasc').value = '';
    document.getElementById('CEP').value = '';
    document.getElementById('endereco').value = '';
    document.getElementById('num').value = '';
};

// Chame a função para preencher a tabela ao carregar a página
window.onload = preencherTabela;
