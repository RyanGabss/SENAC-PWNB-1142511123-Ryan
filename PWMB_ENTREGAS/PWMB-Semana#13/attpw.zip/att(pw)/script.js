const clientes = [];

const validarCEP = (CEP) => {
    const regexCEP = /^\d{5}-\d{3}$/;
    return regexCEP.test(CEP);
};


const incluirCliente = () => {
    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const UF = document.getElementById('UF').value;
    const dataNascimento = document.getElementById('dtnasc').value;
    const CEP = document.getElementById('CEP').value;
    const endereco = document.getElementById('endereco').value;
    const numero = document.getElementById('num').value;

    // Validação dos campos
    if (!nome || !sobrenome || !UF || !dataNascimento || !endereco || !CEP || !numero || !validarCEP(CEP)) {
        alert('Preencha todos os campos corretamente.');
        return;
    }

    // Criar objeto novoCliente
    const novoCliente = {
        nome,
        sobrenome,
        UF,
        dataNascimento,
        CEP,
        endereco,
        numero
    };

    // Obter a lista atual de clientes do Local Storage
    const dadosLocalStorage = localStorage.getItem('clientes');
    let clientes;

    // Verificar se há clientes no Local Storage
    if (dadosLocalStorage) {
        clientes = JSON.parse(dadosLocalStorage);
    } else {
        // Se não houver clientes, criar uma nova lista
        clientes = [];
    }

    // Verificar se o cliente já existe na lista antes de adicionar
    const clienteExistente = clientes.find(cliente => cliente.nome === novoCliente.nome && cliente.sobrenome === novoCliente.sobrenome);
    if (!clienteExistente) {
        // Adicionar novo cliente à lista existente
        clientes.push(novoCliente);

        // Armazenar a lista atualizada no Local Storage
        localStorage.setItem('clientes', JSON.stringify(clientes));

        // Limpar campos
        limparCampos();

        // Atualizar a tabela na página
        preencherTabela();
    } else {
        alert('Cliente já existe na lista.');
    }
};


const limparCampos = () => {
    document.getElementById('nome').value = '';
    document.getElementById('sobrenome').value = '';
    document.getElementById('UF').value = '';
    document.getElementById('dtnasc').value = '';
    document.getElementById('CEP').value = '';
    document.getElementById('endereco').value = '';
    document.getElementById('num').value = '';
};
